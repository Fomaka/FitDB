<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
      <div class="col-sm-8 ">
              <div class="single-products2">
                  <div class="productinfo text-left">
                      <h2>Тип упражнения:
                          <?php echo $upr['name']; ?>
                      </h2>
                      <h3>Информация об упражнении: <?php echo $upr['info']; ?>
                      </h3>
                  </div>
              </div>
      </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
