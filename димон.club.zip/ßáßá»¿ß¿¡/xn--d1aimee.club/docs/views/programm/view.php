<?php include ROOT . '/views/layouts/header.php'; ?>
<?php $i = 1;?>
<section>
      <div class="col-sm-8 ">
              <div class="single-products2">
                  <div class="productinfo text-left">
                      <h3>Название программы: <?php echo $programm['Info']; ?>
                      </h3>
                      <h3>Часть тела: <?php echo $programm['part']; ?></h3>
                      <h3>Тип программы: <?php echo $programm['type']; ?></h3>
                  </div>

          <h3>Упражнения:</h3>
          <?php foreach ($ufpList as $ufp): ?>
                <h4><?php echo $i++?> упражнение: <?php echo $ufp['name']; ?></h4>

          <?php endforeach; ?>
      </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
