<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
    <div class="container">
        <div class="row">

            <div class="col-lg-6">
                <h4>Информация о нашем сайте</h4>

                <br/>

                <p>Сайт содан в рамках курсовой работы по дициплине Web-программирование 
                   студентом группы 3-Т3О-306Б-16 Дмитрием Фоминым.Он представляет собой
                   информационную систему которая может помочь вам в выборе программ и 
                   упражнений в нелегком деле построения красивого тела</p>

            </div>
        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
