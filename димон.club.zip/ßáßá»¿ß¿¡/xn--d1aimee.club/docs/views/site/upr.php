<?php include ROOT . '/views/layouts/header.php'; ?>
<section>
            <div class="col-sm-12">
                <div class="features_items"><!--features_items-->
                    <?php foreach ($latestProducts as $product): ?>
                        <div class="col-sm-4">

                            <div class="product-image-wrapper">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                        <h2>
                                <a href="/upr/<?php echo $product['id']; ?>">
                                <?php echo $product['name']; ?>
                                            </a>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div><!--features_items-->
        </div>
    </div>

</section>


<?php include ROOT . '/views/layouts/footer.php'; ?>
