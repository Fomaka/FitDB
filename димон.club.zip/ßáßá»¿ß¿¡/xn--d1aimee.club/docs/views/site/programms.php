<?php include ROOT . '/views/layouts/header.php'; ?>
<section>
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <div class="features_items">
                        <?php foreach ($categories as $categoryItem): ?>
                          <div class="col-sm-4">
                              <div class="product-image-wrapper2">
                                  <div class="single-products">
                                      <div class="productinfo text-center">
                                        <a href="/programm/<?php echo $categoryItem['id']; ?>">
                                            <h2><?php echo $categoryItem['name']; ?></h2>
                                        </a>
                                      </div>
                                        </div>

                                </div>
                            </div>
                        <?php endforeach; ?>
                </div>
            </div>

        </div>
    </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
