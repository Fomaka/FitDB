<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
  <div class="container">
    <div class="row">
        <div class="col-sm-12">
            <img class = "imgmain" src="template/images/home/main.jpg" alt="" weight = 100px>
            </div>
        </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
