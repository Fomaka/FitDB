<?php include ROOT . '/views/layouts/header.php'; ?>

<section>
    <div class="container">
      <div class="row">
          <div class="col-sm-12">
              <div class="features_items">
                      <?php foreach ($diseases as $deseasesItem): ?>
                        <div class="col-sm-6">
                            <div class="product-image-wrapper3">
                                <div class="single-products">
                                    <div class="productinfo text-center">
                                          <h2><?php echo $deseasesItem['name']; ?></h2>
                                          <h4><?php echo $deseasesItem['info'];?></h4>
                                          <p><strong>Ограничения: </strong><?php echo $deseasesItem['stops'];?></p>
                                      </a>
                                    </div>
                                      </div>

                              </div>
                          </div>
                      <?php endforeach; ?>

              </div>
          </div>
</section>

<?php include ROOT . '/views/layouts/footer.php'; ?>
