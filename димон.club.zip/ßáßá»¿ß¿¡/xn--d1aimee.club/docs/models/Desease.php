<?php

/**
 * Класс PROGRAMMS - модель для работы с программами
 */
class Desease
{

    /**
     * Возвращает массив программ для списка на сайте
     * @return array <p>Массив с категориями</p>
     */
    public static function getDeseaseList()
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Запрос к БД
        $result = $db->query('Select id,info,name,stops from disease');

        // Получение и возврат результатов
        $i = 0;
        $DeseaseList = array();
        while ($row = $result->fetch()) {
            $DeseaseList[$i]['id'] = $row['id'];
            $DeseaseList[$i]['name'] = $row['name'];
            $DeseaseList[$i]['info'] = $row['info'];
            $DeseaseList[$i]['stops'] = $row['stops'];
            $i++;
        }
        return $DeseaseList;
    }



    /**
     * Возвращает программу с указанным id
     * @param integer $id <p>id категории</p>
     * @return array <p>Массив с информацией о категории</p>
     */
    public static function getDeseaseById($id)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM prog WHERE id = :id';

        // Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);

        // Выполняем запрос
        $result->execute();

        // Возвращаем данные
        return $result->fetch();
    }


}
