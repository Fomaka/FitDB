<?php

/**
 * Класс PROGRAMMS - модель для работы с программами
 */
class PROGRAMMS
{

    /**
     * Возвращает массив программ для списка на сайте
     * @return array <p>Массив с категориями</p>
     */
    public static function getProgrammsList()
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT id,Info,type,part from prog';

        // Используется подготовленный запрос
        $result = $db->prepare($sql);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);

        // Выполнение команды
        $result->execute();

        // Получение и возврат результатов
        $i = 0;
        $categoryList = array();
        while ($row = $result->fetch()) {
            $categoryList[$i]['id'] = $row['id'];
            $categoryList[$i]['name'] = $row['Info'];
                      $categoryList[$i]['type'] = $row['type'];
                                $categoryList[$i]['part'] = $row['part'];
            $i++;
        }
        return $categoryList;
    }



    /**
     * Возвращает программу с указанным id
     * @param integer $id <p>id категории</p>
     * @return array <p>Массив с информацией о категории</p>
     */

     public static function getProgrammsById($id)
     {
         // Соединение с БД
         $db = Db::getConnection();

         // Текст запроса к БД
         $sql = 'SELECT * FROM prog WHERE id = :id';

         // Используется подготовленный запрос
         $result = $db->prepare($sql);
         $result->bindParam(':id', $id, PDO::PARAM_INT);

         // Указываем, что хотим получить данные в виде массива
         $result->setFetchMode(PDO::FETCH_ASSOC);

         // Выполняем запрос
         $result->execute();

         // Возвращаем данные
         return $result->fetch();
     }


     public static function UPRfromPROG($id)
     {
         // Соединение с БД
         $db = Db::getConnection();

         // Текст запроса к БД
         $sql = 'SELECT prog.id, prog.Info, upr.name
FROM     prog INNER JOIN
                  upr_to_prog ON prog.id = upr_to_prog.id_prog INNER JOIN
                  upr ON upr_to_prog.id_upr = upr.id WHERE prog.id=:id';

         // Используется подготовленный запрос
         $result = $db->prepare($sql);
         $result->bindParam(':id', $id, PDO::PARAM_INT);

         // Указываем, что хотим получить данные в виде массива
         $result->setFetchMode(PDO::FETCH_ASSOC);

         // Выполнение команды
         $result->execute();

         // Получение и возврат результатов
         $i = 0;
         $ufpList = array();
         while ($row = $result->fetch()) {
             $ufpList[$i]['id'] = $row['id'];
             $ufpList[$i]['name'] = $row['name'];
             $i++;
         }
         return $ufpList;
     }


}
