<?php

/**
 * Класс PROGRAMMS - модель для работы с программами
 */
class Persons
{

    /**
     * Возвращает массив программ для списка на сайте
     * @return array <p>Массив с категориями</p>
     */
    public static function getPersonsList()
    {
        // Соединение   с БД
        $db = Db::getConnection();

        // Запрос к БД
        $result = $db->query('Select id,Info,Name from Person');

        // Получение и возврат результатов
        $i = 0;
        $PersonList = array();
        while ($row = $result->fetch()) {
            $PersonList[$i]['id'] = $row['id'];
            $PersonList[$i]['Name'] = $row['Name'];
            $PersonList[$i]['Info'] = $row['Info'];
            $i++;
        }
        return $PersonList;
    }



    /**
     * Возвращает программу с указанным id
     * @param integer $id <p>id категории</p>
     * @return array <p>Массив с информацией о категории</p>
     */
    public static function getPersonsById($id)
    {
        // Соединение с БД
        $db = Db::getConnection();

        // Текст запроса к БД
        $sql = 'SELECT * FROM Person WHERE id = :id';

        // Используется подготовленный запрос
        $result = $db->prepare($sql);
        $result->bindParam(':id', $id, PDO::PARAM_INT);

        // Указываем, что хотим получить данные в виде массива
        $result->setFetchMode(PDO::FETCH_ASSOC);

        // Выполняем запрос
        $result->execute();

        // Возвращаем данные
        return $result->fetch();
    }


}
