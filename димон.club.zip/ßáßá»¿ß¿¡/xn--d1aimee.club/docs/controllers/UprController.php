<?php

/**
 * Контроллер ProductController
 * Товар
 */
class UprController
{

    public function actionView($uprId)
    {

        // Получаем инфомрацию о товаре
        $upr = UPR::getUPRSById($uprId);

        // Подключаем вид
        require_once(ROOT . '/views/upr/view.php');
        return true;
    }

}
