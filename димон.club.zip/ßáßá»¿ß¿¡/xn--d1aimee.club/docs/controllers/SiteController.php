<?php

/**
 * Контроллер CartController
 */
class SiteController
{

    /**
     * Action для главной страницы
     */
    public function actionIndex()
    {
        // Список категорий для левого меню
        $categories = PROGRAMMS::getProgrammsList();

        // Список последних товаров
        $latestProducts = UPR::getLatestUPRS(6);


        // Подключаем вид
        require_once(ROOT . '/views/site/index.php');
        return true;
    }

    /**
     * Action для страницы "Контакты"
     */
    public function actionPersons()
    {

        $persons = Persons::getPersonsList();

        // Подключаем вид
        require_once(ROOT . '/views/site/persons.php');
        return true;
    }

    public function actionDisease()
    {
        $diseases = Desease::getDeseaseList();
        // Подключаем вид
        require_once(ROOT . '/views/site/disease.php');
        return true;
    }

    public function actionProgramms()
    {

        $categories = PROGRAMMS::getProgrammsList();
        // Подключаем вид
        require_once(ROOT . '/views/site/programms.php');
        return true;
    }

    public function actionUPR()
    {

      // Список последних товаров
      $latestProducts = UPR::getLatestUPRS(6);
        // Подключаем вид
        require_once(ROOT . '/views/site/upr.php');
        return true;
    }

    /**
     * Action для страницы "О магазине"
     */
    public function actionAbout()
    {
        // Подключаем вид
        require_once(ROOT . '/views/site/about.php');
        return true;
    }

}
