<?php
/**
 * Created by PhpStorm.
 * User: fomin
 * Date: 28.05.2019
 * Time: 18:36
 */
class UFPController
{

    public function actionView($programmID)
    {
        $ufpList = PROGRAMMS::UPRfromPROG($programmID);
        // Подключаем вид
        //require_once(ROOT . '/views/programm/view.php');
        //return true;
    }

}
