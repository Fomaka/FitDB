<?php

/**
 * Контроллер CatalogController
 * Каталог товаров
 */
class ProgrammController
{

  public function actionView($programmID)
  {

      $programm = PROGRAMMS::getProgrammsById($programmID);
      $ufpList = PROGRAMMS::UPRfromPROG($programmID);
      // Подключаем вид
      require_once(ROOT . '/views/programm/view.php');
      return true;
  }

}
