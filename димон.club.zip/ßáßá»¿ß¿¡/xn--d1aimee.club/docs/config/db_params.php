<?php

// Массив с параметрами подключения к базе данных
return array(
    'host' => 'h905154554.mysql',
    'dbname' => 'h905154554_db',
    'user' => 'h905154554_mysql',
    'password' => ':FX5TbFn',
);
