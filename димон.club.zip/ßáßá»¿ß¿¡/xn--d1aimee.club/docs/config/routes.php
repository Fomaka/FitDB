<?php

return array(
    // Упражения:
    'upr/([0-9]+)' => 'upr/view/$1',
    'programm/([0-9]+)' => 'programm/view/$1',
    'disease' => 'site/disease',
    // О фитнес-центре
    'persons' => 'site/persons',
    'about' => 'site/about',
    'upr' => 'site/upr',
    'programms' =>'site/programms',
    // Главная страница
    'index.php' => 'site/index',
    '' => 'site/index',
);
