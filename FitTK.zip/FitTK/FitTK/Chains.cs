﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FitTK
{
    public partial class Chains : Form
    {
        public Chains()
        {
            InitializeComponent();
            LoadDataGW1();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        public void LoadDataGW1()
        {
            string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
            MySqlConnection myConnection = new MySqlConnection(ConnectionString);

            myConnection.Open();

            string query1 = "SELECT prog.id,prog.Info,upr.name FROM upr INNER JOIN upr_to_prog ON upr.id = upr_to_prog.id_upr INNER JOIN prog ON upr_to_prog.id_prog = prog.id";

            MySqlCommand command = new MySqlCommand(query1, myConnection);

            MySqlDataReader reader = command.ExecuteReader();

            List<string[]> data = new List<string[]>();

            while (reader.Read())
            {
                data.Add(new string[3]);

                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
            }
            reader.Close();
            myConnection.Close();

            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);

                myConnection.Open();

                string query1 = "SELECT upr_to_prog.id, prog.id, prog.Info FROM prog INNER JOIN upr_to_prog ON prog.id = upr_to_prog.id_prog INNER JOIN upr ON upr_to_prog.id_upr = upr.id WHERE upr.name= '" + this.textBox1.Text + "';";

                MySqlCommand command = new MySqlCommand(query1, myConnection);

                MySqlDataReader reader = command.ExecuteReader();

                List<string[]> data = new List<string[]>();

                while (reader.Read())
                {
                    data.Add(new string[3]);

                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                    data[data.Count - 1][2] = reader[1].ToString();
                }
                reader.Close();
                myConnection.Close();

                dataGridView2.Rows.Clear();

                foreach (string[] s in data)
                    dataGridView2.Rows.Add(s);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);

                myConnection.Open();

                string query1 = "SELECT upr_to_prog.id, upr.name FROM upr INNER JOIN upr_to_prog ON upr.id = upr_to_prog.id_upr INNER JOIN prog ON upr_to_prog.id_prog = prog.id WHERE prog.info = '" + this.textBox2.Text + "';";

                MySqlCommand command = new MySqlCommand(query1, myConnection);

                MySqlDataReader reader = command.ExecuteReader();

                List<string[]> data = new List<string[]>();

                while (reader.Read())
                {
                    data.Add(new string[2]);

                    data[data.Count - 1][0] = reader[0].ToString();
                    data[data.Count - 1][1] = reader[1].ToString();
                }
                reader.Close();
                myConnection.Close();

                dataGridView2.Rows.Clear();

                foreach (string[] s in data)
                    dataGridView2.Rows.Add(s);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            LoadDataGW1();
            dataGridView2.Rows.Clear();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Pauk f4 = new Pauk();
            f4.Show();
        }
    }
    
}
