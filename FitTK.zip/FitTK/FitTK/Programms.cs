﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FitTK
{
    public partial class Programms : Form
    {
        public Programms()
        {
            InitializeComponent();
            LoadData();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void LoadData()
        {
            string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
            MySqlConnection myConnection = new MySqlConnection(ConnectionString);

            myConnection.Open();

            string query1 = "SELECT Id,Info ,part,type FROM prog ";

            MySqlCommand command = new MySqlCommand(query1, myConnection);

            MySqlDataReader reader = command.ExecuteReader();

            List<string[]> data = new List<string[]>();

            while (reader.Read())
            {
                data.Add(new string[4]);

                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
                data[data.Count - 1][3] = reader[3].ToString();
            }
            reader.Close();
            myConnection.Close();

            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);

                myConnection.Open();

                string query1 = "INSERT INTO prog (info,part,type) VALUES (@info,@part,@type)";
                MySqlCommand command = new MySqlCommand(query1, myConnection);

                command.Parameters.AddWithValue("info", textBox1.Text);

                command.Parameters.AddWithValue("part", textBox2.Text);

                command.Parameters.AddWithValue("type", textBox3.Text);

                command.ExecuteNonQuery();
                MessageBox.Show("Data Insert");
                myConnection.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            LoadData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    //This is my connection string i have assigned the database file address path  
                    string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                    MySqlConnection myConnection = new MySqlConnection(ConnectionString);
                    //This is my update query in which i am taking input from the user through windows forms and update the record.  
                    string Query = "update prog set Info='" + this.textBox1.Text + "',part='" + this.textBox2.Text + "',type='" + this.textBox4.Text + "' where id='" + this.textBox3.Text + "';";
                    //This is  MySqlConnection here i have created the object and pass my connection string.  
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, myConnection);
                    MySqlDataReader MyReader2;
                    myConnection.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    MessageBox.Show("Data Updated");
                    while (MyReader2.Read())
                    {
                    }
                    myConnection.Close();//Connection closed here 
                    textBox1.Clear();
                    textBox2.Clear();
                    textBox3.Clear();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);
                string query1 = "delete from prog where id='" + this.textBox3.Text + "';";
                MySqlCommand command = new MySqlCommand(query1, myConnection);
                MySqlDataReader MyReader2;
                myConnection.Open();
                MyReader2 = command.ExecuteReader();
                MessageBox.Show("Data Deleted");
                while (MyReader2.Read())
                {
                }
                myConnection.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
