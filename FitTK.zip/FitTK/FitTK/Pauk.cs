﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FitTK
{
    public partial class Pauk : Form
    {
        public Pauk()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);

                myConnection.Open();

                string query1 = "INSERT INTO upr_to_prog (id_upr,id_prog) VALUES (@id_upr,@id_prog)";
                MySqlCommand command = new MySqlCommand(query1, myConnection);

                command.Parameters.AddWithValue("id_upr", textBox1.Text);

                command.Parameters.AddWithValue("id_prog", textBox2.Text);

                command.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Data Insert");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);
                string query1 = "delete from upr_to_prog where id ='" + this.textBox3.Text + "';";
                MySqlCommand command = new MySqlCommand(query1, myConnection);
                MySqlDataReader MyReader2;
                myConnection.Open();
                MyReader2 = command.ExecuteReader();
                MessageBox.Show("Data Deleted");
                while (MyReader2.Read())
                {
                }
                myConnection.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
