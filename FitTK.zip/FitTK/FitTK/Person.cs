﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace FitTK
{
    public partial class Person : Form
    {
        public Person()
        {
            InitializeComponent();
            LoadData();

        }
        private void LoadData()
        {
            string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
            MySqlConnection myConnection = new MySqlConnection(ConnectionString);

            myConnection.Open();

            string query1 = "select * from Person";

            MySqlCommand command = new MySqlCommand(query1, myConnection);

            MySqlDataReader reader = command.ExecuteReader();

            List<string[]> data = new List<string[]>();

            while (reader.Read())
            {
                data.Add(new string[4]);

                data[data.Count - 1][0] = reader[0].ToString();
                data[data.Count - 1][1] = reader[1].ToString();
                data[data.Count - 1][2] = reader[2].ToString();
            }
            reader.Close();
            myConnection.Close();

            foreach (string[] s in data)
                dataGridView1.Rows.Add(s);
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            LoadData();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);

                myConnection.Open();

                string query1 = "INSERT INTO Person (name,info) VALUES (@name,@info)";
                MySqlCommand command = new MySqlCommand(query1, myConnection);

                command.Parameters.AddWithValue("name", textBox1.Text);

                command.Parameters.AddWithValue("info", textBox2.Text);

                command.ExecuteNonQuery();
                myConnection.Close();
                MessageBox.Show("Data Insert");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                //This is my connection string i have assigned the database file address path  
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);
                //This is my update query in which i am taking input from the user through windows forms and update the record.  
                string Query = "update Person set name='" + this.textBox1.Text + "',info='" + this.textBox2.Text + "' where id='" + this.textBox3.Text + "';";
                //This is  MySqlConnection here i have created the object and pass my connection string.  
                MySqlCommand MyCommand2 = new MySqlCommand(Query, myConnection);
                MySqlDataReader MyReader2;
                myConnection.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                MessageBox.Show("Data Updated");
                while (MyReader2.Read())
                {
                }
                myConnection.Close();//Connection closed here  
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string ConnectionString = "server=localhost;user id=h905154554_mysql;password=:FX5TbFn;database=h905154554_db";
                MySqlConnection myConnection = new MySqlConnection(ConnectionString);
                string query1 = "delete from Person where id='" + this.textBox3.Text + "';";
                MySqlCommand command = new MySqlCommand(query1, myConnection);
                MySqlDataReader MyReader2;
                myConnection.Open();
                MyReader2 = command.ExecuteReader();
                MessageBox.Show("Data Deleted");
                while (MyReader2.Read())
                {
                }
                myConnection.Close();
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
